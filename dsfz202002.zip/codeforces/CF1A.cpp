#include<bits/stdc++.h>

using namespace std;

signed main(void){
    unsigned long long n,m,a;
    unsigned long long c,d;
    cin>>n>>m>>a;
    c=n/a+(n%a!=0);
    d=m/a+(m%a!=0);
    cout<<c*d;
    return 0;
}
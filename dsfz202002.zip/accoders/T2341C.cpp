#include<iostream>
#include<cstdio>
#include<string>

using namespace std;

string names[50005];
int fa[50005];
int sum=0;

inline int find(int a){
	if(fa[a]==a) return a;
	int x=find(fa[a]);
	fa[a]=x;
	return x;
}


void merge(int a,int b){
	fa[find(a)]=find(b);
	
}

void init(){
	for(int i=0;i<50005;i++){
		fa[i]=i;
	}
}

int convert(string a){
	for(int i=0;i<sum;i++){
		if(names[i]==a) return i;
	}
	names[sum++]=a;
	return sum-1;
}


int main(void){
	string f,s;
	char ch;
	init();
	do{
		cin>>ch;
		if(ch=='#')
			cin>>f;
		else if(ch=='+'){
			cin>>s;
			if(f!=s)
				merge(convert(s),convert(f));
		}else if(ch=='?'){
			cin>>s;
			cout<<s<<" "<<names[find(convert(s))]<<endl;
		}
		
		
	}while(ch!='$');
	return 0;
	
	
}

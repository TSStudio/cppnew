#include<iostream>
#include<cstdio>
using namespace std;

int fa[100005];

int n,m;
void init(int n){
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
}
inline int find(int n){
	if(fa[n]==n) return n;
	int sl=find(fa[n]);
	fa[n]=sl;
	return sl;
	
}
void merge(int a,int b){
	fa[find(a)]=find(b);
}

int main(void){
  	scanf("%d%d",&n,&m);
	init(n);
	for(int i=0;i<m;i++){
		int ta,tb;
		scanf("%d%d",&ta,&tb);
		merge(ta,tb);
	}
	int p;
	scanf("%d",&p);
	for(int i=0;i<p;i++){
		int ta,tb;
		scanf("%d%d",&ta,&tb);
		if(find(ta)==find(tb)) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}

#include<bits/stdc++.h>

using namespace std;
const int maxN=10005;
int n;
int nums[maxN];
int main(void){
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>nums[i];
    }
    int sum=0;
    for(int i=0;i<n-1;i++){for(int j=0;j<n-1-i;j++){if(nums[j]>nums[j+1]){swap(nums[j],nums[j+1]);sum++;}}}
    // ONLY FOR DEBUGGING
    // for(int i=0;i<n;i++){
    //     printf("%d ",nums[i]);
    // }
    //
    //
    // printf("\n%d",sum);
    printf("%d",sum);
    return 0;
}
#include<bits/stdc++.h>

using namespace std;
typedef long long ll;

ll c;

inline ll pows(int a,int b){
    if(b==0) return 1;
    if(b==1) return a%c;
    ll d=pows(a,b/2);
    if(b%2==0){
        return (d*d)%c;
    }else{
        return (d*d*a)%c;
    }
}


int main(void){
    ll a,b;
    cin>>a>>b>>c;
    cout<<pows(a,b);
    return 0;
}
#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
const int maxn = 1e6+10;
map<ull,int>maap;
ull power[maxn],base=27,mod=998244353;
int main(){
	int t;
    cin>>t;
	getchar();
	while(t--){
		string line,opera,str,buf;
		cin>>opera;getchar();
		getline(cin,str);
		int len=str.length();ull s=0;
		for(int i=0;i<len;i++){
			s=(s*base+(ull)(str[i]-'\0'))%mod;
		}
		if(opera=="find"){
			if(maap[s]==1) printf("yes\n");
			else printf("no\n");
		}else{
			maap[s]=1;
		}
	}
}
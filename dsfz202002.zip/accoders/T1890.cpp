#include<bits/stdc++.h>

using namespace std;

int k,n;
int nums[100005];

bool cmp(int a,int b){
    return a>b;
}

int main(void){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&nums[i]);
    }
    scanf("%d",&k);
    sort(nums,nums+n,cmp);
    for(int i=0;i<k;i++){
        printf("%d\n",nums[i]);
    }
    return 0;
}
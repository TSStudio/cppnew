#include<bits/stdc++.h>

using namespace std;

typedef unsigned long long ull;
const int maxN=500005;
int scrn[maxN];
int n,w;
int nmax;
bool cmp(int a,int b){
    return a>b;
}

int main(void){
    cin>>n>>w;
    for(int i=1;i<=n;i++){
        nmax=max(1,int(floor(i*w/100)));
        cin>>scrn[i];
        sort(scrn+1,scrn+i+1,cmp);
        cout<<scrn[min(i,nmax)]<<" ";
    }
    return 0;
}
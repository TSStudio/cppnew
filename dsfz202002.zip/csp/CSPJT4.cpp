#include<bits/stdc++.h>

using namespace std;

const int maxN=1005;
int maap[maxN][maxN];
long long smax[maxN][maxN][3];//from up=0 left=1 down=2
int n,m;

signed main(void){
    //use DP algorithm
    //min score for each block
    //input
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            scanf("%d",&maap[i][j]);
            smax[i][j][0]=-1e14;
            smax[i][j][1]=-1e14;
            smax[i][j][2]=-1e14;
        }
    }
    smax[0][0][0]=maap[0][0];
    smax[0][0][1]=maap[0][0];
    smax[0][0][2]=maap[0][0];
    //dp
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            if(i==0&&j>0){
                smax[j][i][0]=maap[j][i]+smax[j-1][i][0];
            }else{
                if(j==0&&i!=0){
                    smax[j][i][1]=maap[j][i]+max(smax[j][i-1][0],max(smax[j][i-1][1],smax[j][i-1][2]));
                }
                if(j>0){
                    smax[j][i][1]=maap[j][i]+max(smax[j][i-1][0],max(smax[j][i-1][1],smax[j][i-1][2]));
                    smax[j][i][0]=maap[j][i]+max(smax[j-1][i][0],smax[j-1][i][1]);
                }
            }
        }
        for(int j=n-2;j>=0;j--){
            smax[j][i][2]=maap[j][i]+max(smax[j+1][i][1],smax[j+1][i][2]);
        }
    }
    //THIS IS FOR DEBUGGING
    //for(int i=0;i<n;i++){
    //    for(int j=0;j<m;j++){
    //        printf("%d ",max(max(smax[i][j][0],smax[i][j][1]),smax[i][j][2]));
    //    }
    //    printf("\n");
    //}
    //printf("##################\n");
    printf("%lld",max(smax[n-1][m-1][0],smax[n-1][m-1][1]));
}
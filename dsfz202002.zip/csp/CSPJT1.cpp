#include<iostream>
#include<cstdio>

using namespace std;

int main(void){
	unsigned long long in;
	cin>>in;
	if(in&1==1){
		cout<<-1;
		return 0;
	}
	int from;
	for(int i=0;;i++){
		if((in>>i)==0){
			from=i-1;
			break;
		}
	}
	for(int i=from;i>0;i--){
		if((in>>i)&1==1)
			cout<<(2<<(i-1))<<" ";
	}
	return 0;
}

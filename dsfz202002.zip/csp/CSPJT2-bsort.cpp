#include<bits/stdc++.h>

using namespace std;

typedef unsigned long long ull;
const int maxN=500005;
int scrn[601];
int n,w;
int nmax;

int main(void){
    cin>>n>>w;
    for(int i=1;i<=n;i++){
        nmax=max(1,int(floor(i*w/100)));
        int temp;
        cin>>temp;
        scrn[temp]++;
        int sum=0;
        for(int i=600;i>=0;i--){
            sum+=scrn[i];
            if(sum>=nmax){
                cout<<i<<" ";
                break;
            }
        }
    }
    return 0;
}
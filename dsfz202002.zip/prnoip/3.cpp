#include<bits/stdc++.h>

#define N 10005
using namespace std;
priority_queue<int>q;
int main(){
	int n,i,x,t,ans=0;
	scanf("%d",&n);
	for(i=1;i<=n;++i){
		scanf("%d",&x);
		q.push(-x);
	}
	while(--n){
		t=0;
		t-=q.top();q.pop();
		t-=q.top();q.pop();
		ans+=t;
		q.push(-t);
	}
	printf("%d",ans);
	return 0;
}
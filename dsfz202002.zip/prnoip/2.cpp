#include<vector>
#include<cstdio>
#include<queue>
#define MAXN 2505
#define INF 1e13
using namespace std;
struct edge{
    int v,w;
};
long long dis[MAXN];
vector<edge> e[MAXN];
queue<int> dot;
inline void insert(int _u,int _v,int _w){
    e[_u].push_back({_v,_w}); //如果是无向图，则要改为 e[u].push_back({v,w});e[v].push_back({u,w});
    e[_v].push_back({_u,_w});
}
int n,m;

void SPFA(){
    while(!dot.empty()){
        int d=dot.front();
        dot.pop();
        for(int i=0;i<e[d].size();i++){
            if(dis[e[d][i].v]>dis[d]+e[d][i].w){
                dis[e[d][i].v]=dis[d]+e[d][i].w;
                dot.push(e[d][i].v);
            }
        }
        
    }
}
int main(){
    int Ts,Te;
    scanf("%d%d%d%d",&n,&m,&Ts,&Te);
    int u,v,w;
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&u,&v,&w);
        insert(u,v,w);
    }
    for(int i=1;i<=n;i++){
        dis[i]=INF;
    }
    dis[Ts]=0;
    //SPFA
    //1->N
    //先把1入队
    dot.push(Ts);
    SPFA();
    printf("%lld",dis[Te]);
    return 0;
} 
#include<cstdio>
#include<queue>

std::priority_queue<long long> minq;
std::priority_queue<long long,std::vector<long long>,std::greater<long long> > maxq;

int main(){
    int n,f;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&f);
        minq.push(f);
        maxq.push(f);
    }
    while(minq.size()>1){
        long long a,b;
        a=minq.top();minq.pop();
        b=minq.top();minq.pop();
        minq.push(a*b+1);
    }
    while(maxq.size()>1){
        long long a,b;
        a=maxq.top();maxq.pop();
        b=maxq.top();maxq.pop();
        maxq.push(a*b+1);
    }
    printf("%lld",maxq.top()-minq.top());
}
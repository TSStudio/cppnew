#include<cstdio>
#pragma GCC optimize(2)

inline void read(int &v){
    register int num;char a;bool flag=0;
    while((a=getchar())<48||a>57)flag^=!(a^'-');
    num=a^48;
    while((a=getchar())>=48&&a<=57)num=(num<<3)+(num<<1)+(a^48);
    v=flag? -num:num;
    return;
}
int main(){
    int N,M,C,SUM=0,ANS=0;
    read(N);read(M);
    while(N--){
        read(C);
        if(SUM+C>M){
            ANS++;SUM=C;
        }else{
            SUM+=C;
        }
    }
    printf("%d",ANS+1);
}
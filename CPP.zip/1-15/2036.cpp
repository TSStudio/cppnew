#include<cstdio>
#include<algorithm>

struct game{
    int et,fine;
}g[505];
bool cmp(game a,game b){
    return a.fine>b.fine;
}
bool isUsed[505];
int main(){
    int m,n;
    scanf("%d%d",&m,&n);
    for(int i=0;i<n;i++){
        scanf("%d",&g[i].et);
    }
    for(int i=0;i<n;i++){
        scanf("%d",&g[i].fine);
    }
    std::sort(g,g+n,cmp);
    for(int i=0;i<n;i++){
        for(int j=g[i].et-1;j>=-1;j--){
            if(j==-1){
                m-=g[i].fine;
                break;
            }
            if(isUsed[j]) continue;
            isUsed[j]=true;
            break;
        }
    }
    printf("%d",m);
}
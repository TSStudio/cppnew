#include<cstdio>
#include<algorithm>
#pragma GCC optimize(2)
const int maxN=30005;

struct req{
    int b,e,t;
}r[maxN];
bool isTreed[maxN];
bool cmp(req a,req b){
    if(a.e==b.e){
        return a.b<b.b;
    }
    return a.e<b.e;
}
int main(){
    int n,h,sum=0;
    scanf("%d%d",&n,&h);
    for(int i=0;i<h;i++){
        scanf("%d%d%d",&r[i].b,&r[i].e,&r[i].t);
    }
    std::sort(r,r+h,cmp);
    for(int i=0;i<h;i++){
        int k=0;
        for(int j=r[i].b;j<=r[i].e;j++){
            k+=isTreed[j];
        }
        if(k<r[i].t){
            for(int j=r[i].e;k<r[i].t;j--){
                if(!isTreed[j]){
                    isTreed[j]=true;
                    k++;
                    sum++;
                }
            }
        }
    }
    printf("%d",sum);
    return 0;
}
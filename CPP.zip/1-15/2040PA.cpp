#include<cstdio>
#include<algorithm>
#pragma GCC optimize(2)

#define N 1000010
using namespace std;
int f[N];
int n,flag;
struct node{
    int e,s;
}eg[N];
bool cmp(node x,node y){
    if(x.s==y.s)
        return x.e<y.e;
    return x.s>y.s;
}
void init(){
    for(int i=0;i<N;i++)
        f[i]=i;
}
int check(int x){
    if(x<=0)
        return x;
    else if(x==f[x]){
        f[x]=x-1;
        flag=1;
        return f[x];
    }
    else return f[x]=check(f[x]);
}
int main(){
    unsigned long long sum=0;
    init();
    scanf("%d",&n);
    sum+=n;
    for(int i=0;i<n;i++){
        scanf("%d%d",&eg[i].e,&eg[i].s);
        sum+=eg[i].e+eg[i].s;
    }
    std::sort(eg,eg+n,cmp);
    int ans=0;
    for(int i=0;i<n;i++){
        flag=0;
        f[eg[i].e]=check(eg[i].e);
        if(flag)ans+=eg[i].s;
    }
    printf("%d\n%llu\n",ans,sum);
}
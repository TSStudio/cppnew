#include<cstdio>

template<typename T> static inline T max(T v1, T v2){
	return (v1>v2)?v1:v2;
}

int main(){
    printf("%d\n",max(1,2));
    printf("%lf\n",max(0.1,0.2));
}
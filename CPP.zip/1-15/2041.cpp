#include<cstdio>
#include<queue>
#pragma GCC optimize(2)

const int N=110;
int n,h,t[N],reduce[N],anss;
struct node{
	int num,id;
	bool operator <(node x)const{
		return x.num>num;
	}
}a[N];
int main(){
	scanf("%d%d",&n,&h);
	h*=12;
	for (int i=1;i<=n;i++) {
		scanf("%d",&a[i].num);
		a[i].id=i;
	}
	for(int i=1;i<=n;i++) scanf("%d",&reduce[i]);
	for(int i=2;i<=n;i++) scanf("%d",&t[i]);
	for(int i=1;i<=n;i++){
		int cnt=0;
		h-=t[i];
		std::priority_queue <node> q;
		for(int j=1;j<=i;j++) q.push(a[j]);
	    for(int j=1;j<=h;j++){
			node now=q.top();
			if(now.num>0){
				cnt+=now.num;
				now.num-=reduce[now.id];
				q.pop();
				q.push(now);
			}
		}
		anss=std::max(anss,cnt);
	}
	printf("%d",anss);
	return 0;
}
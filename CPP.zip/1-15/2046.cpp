#include<cstdio>
#pragma GCC optimize(3)

int n,m,ans;
int seq[1000005];
bool chk(int ma){
    int sum=0,k=1;
    for(int i=0;i<n;i++){
        sum+=seq[i];
        if(sum>ma){
            if(seq[i]>ma) return false;
            sum=seq[i];
            k++;
        }
    }
    if(k<=m) return true;
    return false;
}
int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++){
        scanf("%d",&seq[i]);
    }
    int l=0,r=1e9;
    while(l<=r){
        int mid=(l+r)>>1;
        if(chk(mid)){r=mid-1;ans=mid;}
        else l=mid+1;
    }
    printf("%d",ans);
}
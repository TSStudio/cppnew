#include<cstdio>
#pragma GCC optimize(3)
using namespace std;
double H,D,h;
double chk(double x){
	double L1=(D-x);
	double L2=H-(H-h)*D/x;
	return L1+L2;
}
int main(){
	int T; scanf("%d",&T);
	while(T--){
		scanf("%lf%lf%lf",&H,&h,&D);
		double l=(H-h)*D/H,r=D;
		while(r-l>=1e-9){
			double mid1=l+(r-l)/3.0,mid2=r-(r-l)/3.0;
			if(chk(mid1)>chk(mid2))r=mid2;
			else l=mid1;
		}
		printf("%.3lf\n",chk(r));
	}
	return 0;
}
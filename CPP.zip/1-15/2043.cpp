#include<cstdio>
#include<algorithm>
#pragma GCC optimize(3)

const int size=100005;
int n,c,ans;
int arr[size];
bool chk(int x){
    int cnt=1,last=1;
    for(int i=2;i<=n;i++){
        if(arr[i]-arr[last]>=x){
            cnt++;
            last=i;
        }
        if(cnt>=c){
            return true;
        }
    }
    return false;
}
int main(){
    scanf("%d%d",&n,&c);
    for(int i=1;i<=n;i++){
        scanf("%d",&arr[i]);
    }
    std::sort(arr+1,arr+n+1);

    int left=arr[1],right=arr[n]-arr[1];
    while(left<=right){
        int mid=(left+right)>>1;
        if(chk(mid)){
            left=mid+1;
            ans=mid;
        }else{
            right=mid-1;
        }
    }
    printf("%d",ans);
}
#include<cstdio>
#include<cmath>
#define max(x,y) (x)>(y)?(x):(y)
#define min(x,y) (x)<(y)?(x):(y)
int N,M;
int minArea=1<<30;
int minA[22]={0},minV[22]={0};
int area=0;

int maxVJudge(int m,int r,int h);
void Dfs(int v,int n,int r,int h);

int main(){
    scanf("%d%d",&N,&M);
    for(int i=1;i <= M;i++){
        minA[i]=minA[i-1]+2*i*i;
        minV[i]=minV[i-1]+i*i*i;
    }
    int MaxH=(N-minV[M-1])/(M*M)+1;
    int MaxR=sqrt((N-minV[M-1])/M)+1;
    Dfs(N,M,MaxR,MaxH);
    if(minArea==1<<30)
        printf("0");
    else
        printf("%d",minArea);
    return 0;
}

int maxVJudge(int m,int r,int h){
    int maxV=0;
    for(int i=0;i<m;i++)
        maxV+=(r-i)*(r-i)*(h-i);
    return maxV;
}

void Dfs(int v,int n,int r,int h){
    if(n==0){
        if(v) return;
        else{
            minArea=min(minArea,area);
            return;
        }
    }
    if(v<= 0) return;
    if(minV[n]>v) return;
    if(maxVJudge(n,r,h)<v) return;
    if(minA[n]+area>=minArea) return;
    for(int rr=r;rr>=n;--rr){
        if(n==M) area=rr*rr;
        for(int hh=h;hh>=n;--hh){
            area+=2*rr*hh;
            Dfs(v-rr*rr*hh,n-1,rr-1,hh-1);
            area-=2*rr*hh;
        }
    }
}
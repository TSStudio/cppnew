#include<algorithm>
#include<cstdio>
#include<vector>
struct item{
    int A,B;
};
item tmp;
std::vector<item> it;
struct Node{
    int mi,num;
}node[1005];
int arrangement[1005];
bool cmp(Node a,Node b){
    return a.mi<b.mi;
}
int main(){
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&tmp.A);
        it.push_back(tmp);
    }
    for(int i=0;i<n;i++){
        scanf("%d",&it[i].B);
    }
    for(int i=0;i<n;i++){
        node[i].mi=std::min(it[i].A,it[i].B);
        node[i].num=i;
    }
    std::sort(node,node+n,cmp);
    int front=0,tail=n-1;
    for(int i=0;i<n;i++){
        if(node[i].mi==it[node[i].num].A){
            arrangement[front]=node[i].num;
            front++;
        }else{
            arrangement[tail]=node[i].num;
            tail--;
        }
    }
    int afi[1005]={},bfi[1005]={},lst=0;
    for(int i=0;i<n;i++){
        afi[i]=lst+it[arrangement[i]].A;
        lst=afi[i];
    }
    lst=it[arrangement[0]].A;
    for(int i=0;i<n;i++){
        bfi[i]=std::max(lst,afi[i])+it[arrangement[i]].B;
        lst=bfi[i];
    }
    printf("%d",bfi[n-1]);
}
#include<cstdio>
#include<cctype>
#include<algorithm>
#pragma GCC optimize(3)
inline int read(){
    int x=0; bool f=1; char c=getchar();
    for(;!isdigit(c);c=getchar()) if(c=='-') f=0;
    for(; isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+c-'0';
    if(f) return x;
    return 0-x;
}
int n,m,a[66],next[66],cnt,sum,len;
bool isUsed[66],flg; 
bool cmp(int a,int b){return a>b;}
void dfs(int k,int last,int rest){
    int i;
    if(!rest){
        if(k==m){flg=1; return;}
        for(i=1;i<=cnt;i++)
            if(!isUsed[i]) break;
        isUsed[i]=1; 
        dfs(k+1,i,len-a[i]);
        isUsed[i]=0;
        if(flg) return;
    }
    int l=last+1, r=cnt, mid;
    while(l<r){
        mid=(l+r)>>1;
        if(a[mid]<=rest) r=mid;
        else l=mid+1;
    }
    for(i=l;i<=cnt;i++){
        if(!isUsed[i]){
            isUsed[i]=1;
            dfs(k,i,rest-a[i]);
            isUsed[i]=0;
            if(flg) return;
            if(rest==a[i] || rest==len) return;
            i=next[i];
            if(i==cnt) return;
        }
    }
}
int main(){
    n=read();
    int d;
    for(int i=1;i<=n;i++){
        d=read();
        if(d>50) continue;
        a[++cnt]=d;
        sum+=d;
    }
    std::sort(a+1,a+cnt+1,cmp);
    next[cnt]=cnt;
    for(int i=cnt-1;i>0;i--){
        if(a[i]==a[i+1]) next[i]=next[i+1];
        else next[i]=i;
    }
    for(len=a[1];len<=sum/2;len++){
        if(sum%len!=0) continue;
        m=sum/len;
        flg=0;
        isUsed[1]=1;
        dfs(1,1,len-a[1]);
        isUsed[1]=0;
        if(flg){printf("%d\n",len);return 0;}
    }
    printf("%d\n",sum);return 0;
}
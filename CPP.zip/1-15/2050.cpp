#include<cstdio>

int dfs(int n,int k){
    if(n==0||n<k||k==0) return 0;
    if(n==k||k==1) return 1;
    return dfs(n-1,k-1)+dfs(n-k,k);
}
int main(){
    int n,k;
    scanf("%d%d",&n,&k);
    printf("%d",dfs(n,k));
}

#include<cstdio>
#include<cmath>
#pragma GCC optimize(3)
int T;
struct node{
	double x,y;
}a[15005];
int main(){
	scanf("%d",&T);
	while(T--){
		int n,l,w;
		scanf("%d%d%d",&n,&l,&w);
		int cnt=0;
		for(int i = 1;i <= n;i++){
			int p,q;
			scanf("%d%d",&p,&q);
			if(2*q<=w) continue;
			cnt++;
            double d=sqrt((q*q)-(w*w)/4.0);
			a[cnt].x=p-d;
			a[cnt].y=p+d;
		}
		double t=0;
		int ans=0;
		while(t<l){
			ans++;
			double s=t;
			for(int i=1;i<=cnt;i++){
				if(a[i].x<=s&&t<a[i].y)t=a[i].y;	
			}
			if(t==s&&s<l){
				printf("-1\n");
				return 0;
			}
		}
		printf("%d\n",ans); 
	}
	return 0;
}
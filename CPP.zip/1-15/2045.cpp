#include<cstdio>
#define max(x,y) (x)>(y)?(x):(y)

int n,a[10000],b[10000],c[10000];

double f(double x){
    double maxx=-1e9;
    for(int i=0;i<n;i++){
        maxx=max(maxx,(a[i]*x*x)+(b[i]*x)+c[i]);
    }
    return maxx;
}
int main(){
    int T;
    scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        for(int i=0;i<n;i++){
            scanf("%d%d%d",&a[i],&b[i],&c[i]);
        }
        double l=0,r=1000;
        while (r-l>=1e-11){
			double m1=l+(r-l)/3,m2=r-(r-l)/3;
			if(f(m1)<=f(m2)) r=m2;
			else l=m1;
		}
        printf("%.4lf\n",f(l));
    }
}
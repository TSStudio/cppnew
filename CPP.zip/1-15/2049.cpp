#include<bits/stdc++.h>
#pragma GCC optimize(3)

#define BS (505)
#define eps (1e-8)

using namespace std;

const int cnt=500;

struct vec{
	double x,y;
	vec operator+(const vec oth) const{
		return (vec){x+oth.x,y+oth.y};
	}
	vec operator-(const vec oth) const{
		return (vec){x-oth.x,y-oth.y};
	}
	vec operator*(const double d) const{
		return (vec){x*d,y*d};
	}
	vec operator/(const double d) const{
		return (vec){x/d,y/d};
	}
};

vec A,B,C,D,P1,P2;
double P,Q,R,rx,ry;
vec f1(double x) {return A+P1*x;}
vec f2(double x) {return D+P2*x;}
double Squ(double a) {return a*a;}
double dis(vec a,vec b){
	return sqrt(Squ(a.x-b.x)+Squ(a.y-b.y));
}
double f(double x,double y){
	return x+y+dis(f1(x),f2(y))/R;
}
double Rand() {return (double)rand()/RAND_MAX;}
struct Bird{double vx,vy,x,y,f,pb,pbx,pby;} b[BS];
double w=1,gb=1e233,gbx,gby;
void Update(int a){
	b[a].vx=b[a].vx*w+Rand()*w*(gbx+b[a].pbx-b[a].x*2);
	b[a].vy=b[a].vy*w+Rand()*w*(gby+b[a].pby-b[a].y*2);
	b[a].x+=b[a].vx,b[a].y+=b[a].vy;
	if(b[a].x<0) b[a].x=0,b[a].vx=-b[a].vx;
	if(b[a].y<0) b[a].y=0,b[a].vy=-b[a].vy;
	if(b[a].x>rx) b[a].x=rx,b[a].vx=-b[a].vx;
	if(b[a].y>ry) b[a].y=ry,b[a].vy=-b[a].vy;
	b[a].f=f(b[a].x,b[a].y);
	if(b[a].f<b[a].pb)
		b[a].pbx=b[a].x,b[a].pby=b[a].y,b[a].pb=b[a].f;
}

int main(int argc,char const* argv[]){
	scanf("%lf%lf%lf%lf",&A.x,&A.y,&B.x,&B.y),P1=B-A;
	scanf("%lf%lf%lf%lf",&C.x,&C.y,&D.x,&D.y),P2=C-D;
	scanf("%lf%lf%lf",&P,&Q,&R),srand(P+Q+R);
	rx=dis(B,A)/P,ry=dis(D,C)/Q;
	if(!rx) P1.x=P1.y=0; else P1=P1/rx;
	if(!ry) P2.x=P2.y=0; else P2=P2/ry;
	for(int i=1; i<=cnt; i+=1){
		b[i].x=b[i].pbx=Rand()*rx,b[i].y=b[i].pby=Rand()*ry;
		b[i].f=b[i].pb=f(b[i].x,b[i].y);
		b[i].vx=b[i].vy=0;
		if(gb>b[i].pb) gbx=b[i].pbx,gby=b[i].pby,gb=b[i].pb;
	}
	for(int p=1; p<=900; p+=1,w*=0.99)
		for(int i=1; i<=cnt; i+=1)
			if(Update(i),gb>b[i].pb)
				gbx=b[i].pbx,gby=b[i].pby,gb=b[i].pb;
	printf("%.2f\n",gb);
	return 0;
}
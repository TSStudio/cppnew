#include<cstdio>
#include<algorithm>
#pragma GCC optimize(3)

struct act{
    int s,f;
}a[1002];
bool cmp(act a,act b){
    return a.f<b.f;
}
int sum,n;
int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d%d",&a[i].s,&a[i].f);
    }
    std::sort(a,a+n,cmp);
    int lf=0;
    for(int i=0;i<n;i++){
        if(a[i].s>=lf){
            sum++;
            lf=a[i].f;
        }
    }
    printf("%d",sum);
    return 0;
}
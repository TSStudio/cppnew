#include<cstdio>
#include<cmath>
#define max(x,y) (x)>(y)?(x):(y)
#define abs(x) (((x)>(0))?(x):(-(x)))
#pragma GCC optimize(3)
#define maxn 55

struct ZS{
	int x,y;
}a[maxn];
int n,dis[maxn],g[maxn][maxn],ans;
bool vis[maxn];
void Prim(){
	for(int i=1;i<=n;i++)
	for(int j=i;j<=n;j++) g[i][j]=g[j][i]=(abs(a[i].x-a[j].x)+abs(a[i].y-a[j].y)+1)/2;
	for(int i=1;i<=n;i++) dis[i]=g[1][i];
	vis[1]=1;
	for(int i=1;i<n;i++){
		int Min=1e9,k;
		for(int j=1;j<=n;j++)
		    if(!vis[j]&&dis[j]<Min) Min=dis[j],k=j;
		ans=max(ans,dis[k]),vis[k]=1;
		for(int j=1;j<=n;j++)
		    if(!vis[j]&&g[k][j]<dis[j]) dis[j]=g[k][j];
	}
}
int main(){
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d%d",&a[i].x,&a[i].y);
	Prim();
	printf("%d\n",ans);
	return 0;
}
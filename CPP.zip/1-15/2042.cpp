#include<cstdio>
#include<algorithm>
#pragma GCC optimize(2)

#define LL long long
const int N = 1000000+5;
inline void read(int &v){
    register int num;char a;bool flag=0;
    while((a=getchar())<48||a>57)flag^=!(a^'-');
    num=a^48;
    while((a=getchar())>=48&&a<=57)num=(num<<3)+(num<<1)+(a^48);
    v=flag? -num:num;
    return;
}
inline void readll(LL &v){
    register int num;char a;bool flag=0;
    while((a=getchar())<48||a>57)flag^=!(a^'-');
    num=a^48;
    while((a=getchar())>=48&&a<=57)num=(num<<3)+(num<<1)+(a^48);
    v=flag? -num:num;
    return;
}

LL a[N];
LL next[N];
int main(){
    int n;
    read(n);
    LL sum=0;
    for(int i=1;i<=n;i++){
        readll(a[i]);
        sum+=a[i];
    }
    LL ava=sum/n;
    for(int i=2;i<=n;i++)
        next[i]=next[i-1]+a[i]-ava;
    std::sort(next+1,next+1+n);
    LL res=0;
    for(int i=1;i<=n;i++)
        res+=abs(next[i]-next[(n+1)/2]);
    printf("%lld\n",res);
    return 0;
}
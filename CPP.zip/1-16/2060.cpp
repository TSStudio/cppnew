#include<cstdio>
#include<queue>
#include<set>

std::set<int> s;
inline int statuscode(int a,int b,int c,int d,int e,int f,int g,int h){
    return h+(8*g)+(64*f)+(512*e)+(4096*d)+(32768*c)+(262144*b)+(2097152*a);
}
//op 1:A 2:B 3:C
void bfs(int op){

}
int main(){
    //Arev
    //1 2 3 4 5 6 7 8
    //5 6 7 8 4 3 2 1
    //Brev
    //1 2 3 4 5 6 7 8
    //2 3 4 1 8 5 6 7
    //Crev
    //1 2 3 4 5 6 7 8
    //1 3 7 4 8 6 2 5

    //a b c d e f g h
    //h*8^0 + g*8^1 + f*8^2 + e*8^3 + d*8^4 + c*8^5 + b*8^6 + a*8^7
    //h+8g+64f+512e+4096d+32768c+262144b+2097152a
    //max 18831569

}
#include<cstdio>
#pragma GCC optimize(3)

typedef long long ll;
ll a,b;
ll ans[10010],anss=0;
ll s[10010],t=0;
ll gcd(ll a1,ll b1){
    while(b1^=a1^=b1^=a1%=b1);
    return a1;
}
template<typename T> static inline T max(T v1, T v2){
	return (v1>v2)?v1:v2;
}
ll least(ll x,ll y){
	for(ll i=2;;i++)
	if(x*i>y)return i;
}
bool dfs(ll re,ll x,ll y){
	if(re==1){
		if(x==1&&y>s[t]&&(anss==0||y<ans[anss])){
			anss=++t;s[t]=y;
			for(ll i=1;i<=t;i++)
			    ans[i]=s[i];
			t--;
			return true;
		}
		return false;
	}
	bool getans=false;
	for(ll i=max(s[t]+1,least(x,y));re*y>x*i;i++){
		ll yy(y/gcd(y,i)*i);
		ll xx(x*(yy/y)-yy/i);
		s[++t]=i;
		if(dfs(re-1,xx/gcd(xx,yy),yy/gcd(xx,yy)))getans=true;
		t--;
	}
	return getans;
}
int main(){
    scanf("%lld%lld",&a,&b);
    printf("%lld\n",(a+b)%113);
    ll g=gcd(a,b);
    a/=g,b/=g;
    if(a==1) {printf("%lld",b);return 0;}
    s[0]=1;
	for(ll i=2;;i++){
		t=0;
		if(dfs(i,a,b)){
			for(ll i=1;i<=anss;i++)
			    printf("%lld ",ans[i]);
			return 0;
		}
	}
}
#include<cstdio>
#include<algorithm>
#include<set>

std::set<int> se;
int seq[1005],inp[2010],S[505],sum,n,m;
bool ok;

void dfs(int digit){
    if(digit==n){
        for(int i=0;i<m;i++){
            sum+=S[i];
            if(se.count(sum)){
                dfs(digit+1);
                sum-=S[i];
            }else{    
                sum-=S[i];
                return;
            }
        }
    }
    for(int i=0;i<m;i++){
        sum+=S[i];
        if(se.count(sum)){
            dfs(digit+1);
            sum-=S[i];
        }else{    
            sum-=S[i];
            return;
        }
    }
}

int main(){
    scanf("%d",&n);
    for(int i=0;i<2*n;i++){
        scanf("%d",&inp[i]);
        se.insert(inp[i]);
    }
    scanf("%d",&m);
    for(int i=0;i<m;i++){
        scanf("%d",&S[i]);
    }
    std::sort(S,S+m);
    dfs(1);
}
#include<cstdio>
#include<algorithm>
struct f{
    int rank,sum;
}cou[10];
int a[10][10],line[10][10],row[10][10],gong[10][10],s[100][4],u,ok,most=-1,have;
inline int which(int i,int j){
    return (i-1)/3*3+(j-1)/3+1;
}
const int score[10][10]={{0,0,0,0,0,0,0,0,0,0},{0,6,6,6,6,6,6,6,6,6},{0,6,7,7,7,7,7,7,7,6},{0,6,7,8,8,8,8,8,7,6},{0,6,7,8,9,9,9,8,7,6},{0,6,7,8,9,10,9,8,7,6},{0,6,7,8,9,9,9,8,7,6},{0,6,7,8,8,8,8,8,7,6},{0,6,7,7,7,7,7,7,7,6},{0,6,6,6,6,6,6,6,6,6}};                                                             
void dfs(int p,int score){
    if(p==u){
        if(score>most) most=score;
        return;
    }
    for(int i=1;i<=9;i++) {
        if(!line[s[p][0]][i]&&!row[s[p][1]][i]&&!gong[s[p][3]][i]){
            line[s[p][0]][i]=row[s[p][1]][i]=gong[s[p][3]][i]=1;
            dfs(p+1,score+(s[p][2]*i));
            line[s[p][0]][i]=row[s[p][1]][i]=gong[s[p][3]][i]=0;
        }
    }
    return;
}
bool cmp(f a,f b){
    return a.sum<b.sum; 
}
int main(){
    for(int i=1;i<=9;i++)  cou[i].rank=i;
    for(int i=1;i<=9;i++)
    for(int j=1;j<=9;j++){
        scanf("%d",&a[i][j]);
        if(a[i][j]>0)
        line[i][a[i][j]]=row[j][a[i][j]]=gong[which(i,j)][a[i][j]]=1,have+=a[i][j]*score[i][j];
        else  cou[i].sum++;
    }
    std::sort(cou+1,cou+10,cmp);
    for(int i=1;i<=9;i++){
        for(int j=1;j<=9;j++)
        if(a[cou[i].rank][j]==0)
        s[u][0]=cou[i].rank,s[u][1]=j,s[u][2]=score[cou[i].rank][j],s[u++][3]=which(cou[i].rank,j);
    }
    dfs(0,have);
    printf("%d",most);
    return 0;
}
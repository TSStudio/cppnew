#include<cstdio>
#include<algorithm>
#include<cmath>

const int maxN=1005;

struct req{
    double b,e;
}r[maxN];
bool cmp(req a,req b){
    if(a.e==b.e){
        return a.b>b.b;
    }
    return a.e<b.e;
}
bool ins(int x,int y,int d,int nu){
    if(y>d) return false;
    if(y==d){r[nu].b=x,r[nu].e=x; return true;}
    double delta=sqrt(d*d-(y*y));
    r[nu].b=x-delta,r[nu].e=x+delta;
    return true;
}
int main(){
    int n,d,T=0;
    while(scanf("%d%d",&n,&d)!=EOF){
        T++;
        if(n==0&&d==0) return 0;
        int sum=0;
        bool flg=false;
        printf("Case %d: ",T);
        int x,y;
        for(int i=0;i<n;i++){
            scanf("%d%d",&x,&y);
            if(!ins(x,y,d,i)){flg=true;}
        }
        if(flg){printf("-1\n");continue;}
        std::sort(r,r+n,cmp);
        sum=1;
        double lastradarpos=r[0].e;
        for(int i=1;i<n;i++){
            if(lastradarpos>=r[i].b) continue;
            sum++;
            lastradarpos=r[i].e;
        }
        printf("%d\n",sum);
    }
    return 0;
}
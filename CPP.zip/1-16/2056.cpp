#include<cstdio>
#include<cstring>
#include<cctype>
#include<algorithm>
#pragma GCC optimize(2)
#define LL long long
int n,c,up[17],col[17],f[1<<16][21],l[1<<16]={0,0,1},ans;
struct node{int zsx,zsy,yxx,yxy;}A[17];
template<typename T> static inline T min(T v1, T v2){
	return (v1<v2)?v1:v2;
}
inline int read(){
	char c;int d=1,f=0;
	while(c=getchar(),!isdigit(c)) if(c=='-') d=-1;f=(f<<3)+(f<<1)+c-48;
	while(c=getchar(),isdigit(c)) f=(f<<3)+(f<<1)+c-48;
	return d*f;
}
int main(){
	n=read();
	for(register int i=1;i<=n;i++) A[i]=(node){read(),read(),read(),read()},col[i]=read();
	for(register int i=1;i<=n;i++) for(register int j=1;j<=n;j++) 
	if(i!=j) if(A[i].zsx==A[j].yxx&&((A[j].zsy>=A[i].zsy&&A[j].zsy<=A[i].yxy)||(A[j].yxy>=A[i].zsy&&A[j].yxy<=A[i].yxy))) up[i]|=1<<j-1;
	memset(f,0x3f,sizeof(f));
	for(register int i=1;i<=20;i++) f[0][i]=1;
	for(register int i=1;i<(1<<n);i++){
		if(i>2) l[i]=l[i>>1]+1;
		int x=i;
		while(x&-x){
			int j=l[x&-x]+1;
			if((i|up[j])==i) for(register int k=1;k<=20;k++) f[i][col[j]]=min(f[i][col[j]],f[i-(1<<j-1)][k]+(k!=col[j])); 
			x-=x&-x;
		}
	}
	ans=n;
	for(register int i=1;i<=20;i++) ans=min(ans,f[(1<<n)-1][i]);
	printf("%d",ans);
}
#include<cstdio>
#include<algorithm>
#include<cstring>
/*
n=int(input())

k=input().split()
S=int(k[0])
T=int(k[1])
a=[]
for i in range(1,n+1):
    k=input().split()
    a.append((int(k[0]),int(k[1])))
a.sort(key=lambda x:x[0]*x[1])
ans=0
for i in range(0,n):
    if(S//(a[i])[1]>ans):
        ans=S//(a[i])[1]
    S*=(a[i])[0]
print(ans)
*/
struct it{
    int first,second;
}a[10005];
bool key(it v1,it v2){
    return v1.first*v1.second<v2.first*v2.second;
}
struct bign{
	int d[1000];
	int len;
	bign() {
		memset(d, 0, sizeof(d));
		len = 0;
	}
};

bign change(char str[]) {
	bign a;
	a.len = strlen(str);
	for (int i = 0; i < a.len; i++) {
		a.d[i] = str[a.len - i - 1] - '0';
	}
	return a;
}

bign multi(bign a, int b) {
	bign c;
	int carry = 0;
	for (int i = 0; i < a.len; i++) {
		int temp = a.d[i] * b + carry;
		c.d[c.len++] = temp % 10; 
		carry = temp / 10;
	} 
	while (carry != 0) {
		c.d[c.len++] = carry % 10;
		carry /= 10;
	}
	return c;
}
bign divide(bign a, int b, int &r) {
	bign c;
	c.len = a.len;
	for(int i = a.len - 1; i >= 0; i--) {
		r = r * 10 + a.d[i];
		if (r < b) c.d[i] = 0;
		else {
			c.d[i] = r / b;
			r %= b;
		} 
	} 
	while (c.len - 1 >= 1 && c.d[c.len - 1] == 0) {
		c.len--;
	}
	return c;
}
bign ans;
int main(){
    int n,T;
    char* Ss;bign S;
    scanf("%d%s%d",&n,Ss,&T);
    S=change(Ss);
    for(int i=0;i<n;i++){
        scanf("%d%d",&a[i].first,&a[i].second);
    }
    std::sort(a,a+n,key);
    int r;
    for(int i=0;i<n;i++){
        if(divide(S,a[i].second,r).len>ans.len){
            ans=divide(S,a[i].second,r);
        }
        S=multi(S,a[i].first);
    }
    printf("%llu",ans);
}

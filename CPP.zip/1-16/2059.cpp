#include<cstdio>

bool array[505][505];
//0:/ 1:\ 

int main(void){
    int T;
    scanf("%d",&T);
    while(T--){
        int n,m;
        scanf("%d%d",&n,&m);
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                char c;
                scanf("%c",&c);
                if(c=='/') array[i][j]=0;
                else array[i][j]=1;
            }
        }
        if((n+m)&1){
            printf("NO SOLUTION\n");
        }
    }
}
#include<cstdio>

int main(){
    int T,n;
    long long sum=0;
    scanf("%d",&T);
    sum+=T;
    for(int i=0;i<T;i++){
        scanf("%d",&n);
        sum+=n;
    }
    printf("%lld",sum%117);
}
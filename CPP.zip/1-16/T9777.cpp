#include<cstdio>
#include<algorithm>
#pragma GCC optimize(3)
#pragma GCC target("sse,sse2,sse3,sse4.1,sse4.2,popcnt,abm,mmx,avx")
#pragma comment(linker,"/STACK:102400000,102400000")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")

int n;
long long wangshu=0;
struct ccf{
    int x;
    int y;
};
ccf ioi[300100];
int c[300100];
int a[300100];

bool noip(ccf a,ccf b){return a.x<b.x;}

void init(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",&ioi[i].x,&ioi[i].y);
    std::sort(ioi+1,ioi+1+n,noip);
    for(int i=1;i<=n;i++)
        a[i]=ioi[i].y;
}
void noi(int l,int r){
    int i,j,sjw,ls;
    if(l+1<r){
        sjw=(l+r)/2;
        noi(l,sjw-1);
        noi(sjw,r);
        ls=l;
        for(i=l,j=sjw;(i<=sjw-1)&&(j<=r);){
            if(a[i]>a[j]){
                c[ls++]=a[j++];
                wangshu+=sjw-i;
            }else c[ls++]=a[i++];
        }
        if(j<=r){
            for(;j<=r;j++) c[ls++]=a[j];
        }else{
            for(;i<=sjw-1;i++) c[ls++]=a[i];
        }
        for(int i=l;i<=r;i++) a[i]=c[i];
    }else{
        if(l+1==r){
            if(a[l]>a[r]){
                int tt=a[r];
                a[r]=a[l];
                a[l]=tt;
                wangshu++;
            }
        }
    }
}
int main(){
    init();
    noi(1,n);
    printf("%lld",wangshu);
    return 0;
}
#include<bits/stdc++.h>
using namespace std;
#define re register
#define il inline
il int read(){
    re int x=0,f=1;char c=getchar();
    while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
    while(c>='0'&&c<='9') x=(x<<3)+(x<<1)+(c^48),c=getchar();
    return x*f;
}
#define inf INT_MAX
#define maxn 405
#define maxm 10005
vector <pair<double,double> > infos;
struct edge{
	int v,next;
    double w,money,cost;
}e[maxm<<1];
int head[maxn],cnt,n,m,tot,now=1;
double ansm,ansc;
double dis[maxn];
bool vis[maxn];
il void add(int u,int v,double w,double money,double cost){
    //printf("Inserted %d,%d CMR:%.2lf M:%.1lf C:%.1lf\n",u,v,w,money,cost);
	e[++cnt].v=v;
	e[cnt].w=w;
    e[cnt].money=money;
    e[cnt].cost=cost;
	e[cnt].next=head[u];
	head[u]=cnt;
}
il void init(){
    n=read(),m=read();
    for(re int i=1,u,v,w,c;i<=m;++i){
        u=read(),v=read(),w=read(),c=read();
        infos.push_back(make_pair(w,c));
        add(u,v,double(c)/w,w,c),add(v,u,double(c)/w,w,c);
    }
}
il void prim(){
	for(re int i=2;i<=n;++i){
		dis[i]=inf;
	}
	for(re int i=head[1];i;i=e[i].next){
		dis[e[i].v]=min(dis[e[i].v],e[i].w);
	}
    while(++tot<n){
        re double minn=inf;
        vis[now]=1;
        double money=0,cost=0;
        for(re int i=1;i<=n;++i){
            if(!vis[i]&&minn>dis[i]){
                minn=dis[i];
                //printf("Added Edge #%d M:%.1lf C%.1lf:\n",i,infos[i-1].first,infos[i-1].second);
                money=infos[i-1].first;
                cost=infos[i-1].second;
				now=i;
            }
        }
        ansm+=money;
        ansc+=cost;
        for(re int i=head[now];i;i=e[i].next){
        	re int v=e[i].v;
        	if(dis[v]>e[i].w&&!vis[v]){
        		dis[v]=e[i].w;
        	}
		}
    }
}
int main(){
    init();
    prim();
    printf("%.4lf",ansm/ansc);
    return 0;
}